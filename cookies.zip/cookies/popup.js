// ===== Preset =====
// ⚠️ DÁN PAT của ANH tại đây (fine-grained, Contents: Read & Write cho repo private)
const FIXED_TOKEN     = "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";  // <<< THAY BẰNG TOKEN CỦA ANH
const DEFAULT_REPO    = "tuantao/taof-secrets";         // repo cố định
const DEFAULT_BRANCH  = "main";                          // branch cố định
const DEFAULT_DEVICE  = "DESKTOP-TAOF";                  // gợi ý nhãn thiết bị (tuỳ chỉnh)

// ===== Helpers =====
const $ = (id) => document.getElementById(id);
function safePart(s){ return String(s||"").replace(/[^\w.-]+/g,"_").slice(0,120) || "unknown"; }
function b64(str){ return btoa(unescape(encodeURIComponent(str))); }
function yyyymmdd(){ const d=new Date(); const p=n=>String(n).padStart(2,"0"); return `${d.getFullYear()}${p(d.getMonth()+1)}${p(d.getDate())}`; }

async function getActiveBaseDomain() {
  return new Promise((resolve) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      const t = tabs && tabs[0];
      if (!t || !t.url || !/^https?:/i.test(t.url)) return resolve(null);
      try {
        const u = new URL(t.url);
        const parts = (u.hostname || "").split(".").filter(Boolean);
        resolve(parts.length <= 2 ? u.hostname : parts.slice(-2).join("."));
      } catch {
        resolve(null);
      }
    });
  });
}

async function getCookiesJSON(domain) {
  const clean = (domain || "").trim().replace(/^https?:\/\//, "");
  if (!clean) throw new Error("Domain rỗng.");
  const cookies = await chrome.cookies.getAll({ domain: clean });
  return { exportedAt: new Date().toISOString(), domain: clean, count: cookies.length, cookies };
}

async function uploadRepo(token, ownerRepo, path, branch, content) {
  const [owner, repo] = ownerRepo.split("/");
  if (!owner || !repo) throw new Error("owner/repo không hợp lệ.");
  const url = `https://api.github.com/repos/${owner}/${repo}/contents/${encodeURIComponent(path)}`;
  const body = { message: "TAOF: add cookies", content: b64(content), branch: branch || "main" };
  const res = await fetch(url, {
    method: "PUT",
    headers: { "Authorization": `Bearer ${token}`, "Accept": "application/vnd.github+json" },
    body: JSON.stringify(body)
  });
  if (!res.ok) {
    const t = await res.text().catch(()=> "");
    throw new Error(`GitHub lỗi ${res.status}: ${t.slice(0,200)}`);
  }
  return res.json();
}

// ===== UI init =====
$("repoInfo").textContent = DEFAULT_REPO;
$("branchInfo").textContent = DEFAULT_BRANCH;

let CURRENT_DOMAIN = null;
document.addEventListener("DOMContentLoaded", async () => {
  CURRENT_DOMAIN = await getActiveBaseDomain();
  $("domainInfo").textContent = CURRENT_DOMAIN || "(không đọc được tab hiện tại)";
});

// ===== One-click upload =====
$("btnUpload").addEventListener("click", async () => {
  const status = $("status");
  try {
    if (!FIXED_TOKEN || /your_token_here|github_pat_\.{3}/i.test(FIXED_TOKEN)) {
      throw new Error("Chưa dán token FIXED_TOKEN trong popup.js");
    }
    if (!CURRENT_DOMAIN) {
      CURRENT_DOMAIN = (await getActiveBaseDomain()) || "facebook.com";
    }

    status.innerHTML = "Đang đọc cookie…";
    const data = await getCookiesJSON(CURRENT_DOMAIN);

    // Lấy uid nếu có (Facebook có c_user), nếu không thì 'unknown'
    const uid = (data.cookies.find(c => c.name === "c_user") || {}).value || "unknown";
    const domainPart = safePart(data.domain);
    const uidPart    = safePart(uid);
    const device     = safePart(DEFAULT_DEVICE);

    const payload = JSON.stringify({
      meta: { exportedAt: new Date().toISOString(), domain: data.domain, uid, device },
      cookies: data.cookies
    }, null, 2);

    const ts = new Date().toISOString().replace(/[:.]/g,"-");
    const fileBase = `cookies-${ts}.json`;
    const path     = `cookies/${domainPart}/${uidPart}/${fileBase}`;

    status.innerHTML = `Đang upload → <code>${DEFAULT_REPO}@${DEFAULT_BRANCH}</code><br/><small>${path}</small>`;
    const rr = await uploadRepo(FIXED_TOKEN, DEFAULT_REPO, path, DEFAULT_BRANCH, payload);
    const p  = rr?.content?.path || path;

    status.innerHTML = `<span class="ok">✅ Đã upload:</span> <code>${p}</code>`;
  } catch (e) {
    status.innerHTML = `<span class="err">❌ Lỗi:</span> ${e.message || "không rõ"}`;
  }
});
